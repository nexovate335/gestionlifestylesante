from django.apps import AppConfig

class PersonnelsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'personnels'

    def ready(self):
        import personnels.signals 
